#ifndef __UARTTWO_H
#define __UARTTWO_H
#include "stm32f10x.h"
#include <stdio.h>

void initUART(void);
void initUART2(void);
void sendByte(USART_TypeDef* USARTx, u16 byte);
void sendString(USART_TypeDef* USARTx, char* str);

void USART1_IRQHandler(void);
void USART2_IRQHandler(void);
void USART3_IRQHandler(void);
int fputc(int ch, FILE* f);




#endif
