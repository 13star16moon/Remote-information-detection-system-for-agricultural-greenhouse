#ifndef __NVIC_H
#define __NVIC_H
#include "stm32f10x.h"

void initNVIC(u32 NVIC_PriorityGroup);
void setNVIC(u8 InterruptNum, u8 PreemptionPriority, u8 SubPriority, FunctionalState NVIC_Sta);


#endif
