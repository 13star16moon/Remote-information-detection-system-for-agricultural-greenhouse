#ifndef __LIGHT_H
#define __LIGHT_H
#include "stm32f10x.h"


void initADC(void);

u16 getConvValueAve(u8 counts, u32 xus,u8 ch);

u16 Get_Adc(u8 ch);

u16 Calsoilmoi(u16 soilmoi);
u16 Calwaterlevel(u16 waterlevel);


#endif

