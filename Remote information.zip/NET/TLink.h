#ifndef __TLink_H
#define __TLink_H
#include "stm32f10x.h"


//#define TLINK_IP    "tcp.tlink.io"
#define TLINK_IP    "112.74.142.132"
#define TLINK_PORT  8647
#define APP_ID      "UU2CQSZ2KJZ21DX8"

typedef struct
{
	u8 Relay1;
	u8 Relay2;

	u8 Humidity;
	u8 Temperature;
	u16 DigLight;
	u16 waterlevel;
	u16 soilmoisture;
	
}DeviceSta_Strcture;

u8 connectTlink(void);
void sendDeviceStatus(DeviceSta_Strcture* pdevsta);
void processDeviceStatus(DeviceSta_Strcture* pdevsta);




#endif
